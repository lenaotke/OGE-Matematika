function changeFavour(){}
function toggleAll(open){document.querySelectorAll("#task-view details.solve").forEach(d=>d.open=open);}
/* ===== UX 2026: answers checked against the answer written in the card's own solution ===== */
(function(){
  var STORE='oge2027-fipi-checks-v1';
  function load(){try{return JSON.parse(localStorage.getItem(STORE)||'{}')}catch(e){return{}}}
  function save(s){try{localStorage.setItem(STORE,JSON.stringify(s))}catch(e){}}

  function norm(v){
    return String(v==null?'':v).trim().toLowerCase()
      .replace(/[−–—]/g,'-').replace(/\s+/g,'').replace(/\./g,',').replace(/;+$/,'');
  }
  function isNum(s){return /^-?\d+(,\d+)?$/.test(s)}
  function toNum(s){return parseFloat(s.replace(',','.'))}

  /* the answer from the solution: the «Ответ:» line of this card */
  function solutionAnswer(qid){
    var art=document.getElementById('q'+qid); if(!art) return '';
    var fin=art.querySelector('details.solve .final'); if(!fin) return '';
    return fin.textContent.replace(/^\s*Ответ\s*:\s*/i,'').trim();
  }
  function examNumber(qid){
    var art=document.getElementById('q'+qid); if(!art) return 0;
    var d=art.getAttribute('data-exam-number'); if(d) return parseInt(d,10)||0;
    var h=art.querySelector('.taskhead'); var m=((h?h.textContent:'').match(/№\s*(\d+)/)||[]); return m[1]?+m[1]:0;
  }
  function kindOf(form){
    if(form.querySelector('select[name^="ans"]')) return 'select';
    if(form.querySelector('input[type="checkbox"][name^="test"]')) return 'checkbox';
    if(form.querySelector('input[type="radio"][name="answer"]')) return 'radio';
    return 'text';
  }
  function readAnswer(form){
    var sels=[].slice.call(form.querySelectorAll('select[name^="ans"]'));
    if(sels.length){var v=sels.map(function(x){return x.value});return v.some(function(x){return !x||x==='0'})?'':v.join('');}
    var boxes=[].slice.call(form.querySelectorAll('input[type="checkbox"][name^="test"]'));
    if(boxes.length) return boxes.filter(function(x){return x.checked}).map(function(x){return x.value}).sort().join('');
    var r=form.querySelector('input[type="radio"][name="answer"]:checked'); if(r) return r.value;
    var t=form.querySelector('input[type="text"][name="answer"]'); return t?t.value:'';
  }
  function same(user,key,kind){
    var a=norm(user),b=norm(key);
    if(kind==='checkbox'){a=a.split('').sort().join('');b=b.split('').sort().join('');}
    if(a===b) return true;
    if(kind==='text'&&isNum(a)&&isNum(b)) return Math.abs(toNum(a)-toNum(b))<1e-9;
    return false;
  }

  var toast,toastTimer;
  function showToast(cls,title,sub){
    if(!toast){toast=document.createElement('div');toast.className='check-toast';toast.setAttribute('role','status');toast.setAttribute('aria-live','polite');document.body.appendChild(toast);}
    toast.className='check-toast '+cls;
    toast.innerHTML=title+(sub?'<small>'+sub+'</small>':'');
    requestAnimationFrame(function(){toast.classList.add('show')});
    clearTimeout(toastTimer); toastTimer=setTimeout(function(){toast.classList.remove('show')},2600);
  }

  function setVisual(qid,panel,ok,msgText){
    var status=panel.querySelector('.task-status');
    if(status){status.textContent=ok===null?'НЕ РЕШЕНО':(ok?'ВЕРНО':'НЕВЕРНО');status.className='task-status '+(ok===null?'task-status-0':(ok?'task-status-ok':'task-status-bad'));}
    var host=panel.parentNode.parentNode;
    var msg=host.querySelector('.fipi-check-message');
    if(!msg){msg=document.createElement('div');msg.className='fipi-check-message';host.appendChild(msg);}
    msg.className='fipi-check-message'+(ok===null?'':(ok?' ok':' bad'));
    msg.textContent=msgText||'';
    var form=document.forms['checkform'+qid];
    var inp=form&&form.querySelector('input[type="text"][name="answer"]');
    if(inp){inp.classList.remove('ans-ok','ans-bad'); if(ok!==null) inp.classList.add(ok?'ans-ok':'ans-bad');}
  }

  function updateProgress(){
    var s=load(),ok=0,bad=0,self=0;
    Object.keys(s).forEach(function(k){if(k.indexOf('p2_')===0){if(s[k])self++;}else if(s[k]&&s[k].ok===true)ok++;else if(s[k]&&s[k].ok===false)bad++;});
    [['prog-ok',ok],['prog-bad',bad],['prog-saved',self],['prog-none',Math.max(0,3884-ok-bad-self)]].forEach(function(p){var e=document.getElementById(p[0]);if(e)e.textContent=p[1];});
  }

  window.updateProgress=updateProgress;

  /* part 2: self-check status «Решил сам / Не решено» */
  function panelQid(panel){var t=panel.parentNode.querySelector('.id-text .canselect');return t?t.textContent.trim():'';}
  function setSelf(panel,done){
    var st=panel.querySelector('.task-status'); if(!st) return;
    st.textContent=done?'РЕШЕНО (сверено с разбором)':'НЕ РЕШЕНО';
    st.className='task-status '+(done?'task-status-self':'task-status-0');
  }
  window.changeStatus=function(guid,panel){
    var qid=panelQid(panel); var s=load(); var done=!(s['p2_'+qid]);
    if(done) s['p2_'+qid]=1; else delete s['p2_'+qid]; save(s);
    setSelf(panel,done); updateProgress();
    showToast(done?'ok':'info',done?'Отмечено: решено':'Статус снят',done?'сверь своё решение с критериями':'задание снова «не решено»');
  };

  window.checkButtonClick=function(formName,setter,panel){
    var form=document.forms[formName]; if(!form) return false;
    var qid=formName.replace(/^checkform/,'');
    var user=readAnswer(form);
    if(!norm(user)){
      setVisual(qid,panel,null,'Сначала введи или выбери ответ.');
      showToast('info','Введи свой ответ','поле ответа пустое');
      return false;
    }
    var key=solutionAnswer(qid);
    if(!key){showToast('info','Нет ответа в решении','эта карточка проверяется по ссылке ФИПИ');return false;}
    var ok=same(user,key,kindOf(form));
    setVisual(qid,panel,ok,ok?'Верно! Ответ совпал с ответом в решении.':'Неверно. Открой «Показать полное решение» и сравни шаги, затем попробуй ещё раз.');
    showToast(ok?'ok':'bad',ok?'✓ Верно!':'✗ Неверно',ok?'ответ совпал с решением':'попробуй ещё раз');
    var s=load(); s[qid]={v:user,ok:ok}; save(s); updateProgress();
    return false;
  };

  window.resetAllProgress=function(){
    if(!confirm('Сбросить все введённые ответы и статусы?')) return;
    try{localStorage.removeItem(STORE)}catch(e){}
    document.querySelectorAll('form[name^="checkform"]').forEach(function(f){
      f.querySelectorAll('input[type=radio],input[type=checkbox]').forEach(function(x){x.checked=false});
      f.querySelectorAll('input[type=text]').forEach(function(x){x.value='';x.classList.remove('ans-ok','ans-bad')});
      f.querySelectorAll('select').forEach(function(x){x.selectedIndex=0});
    });
    document.querySelectorAll('.answer-panel').forEach(function(p){
      var st=p.querySelector('.task-status'); if(st){st.textContent='НЕ РЕШЕНО';st.className='task-status task-status-0';}
    });
    document.querySelectorAll('.fipi-check-message').forEach(function(m){m.remove()});
    document.querySelectorAll('.task-status-self').forEach(function(st){st.textContent='НЕ РЕШЕНО';st.className='task-status task-status-0';});
    updateProgress();
  };

  function enhanceForms(){
    var saved=load();
    document.querySelectorAll('form[name^="checkform"]').forEach(function(form){
      var qid=form.name.replace(/^checkform/,'');
      var n=examNumber(qid); if(!n||n>19) return;
      var block=form.querySelector('td.varinats-block')||form;
      if(!block.querySelector('.ans-label')){
        var kind=kindOf(form);
        var lab=document.createElement('div'); lab.className='ans-label';
        lab.textContent=(kind==='text')?'Введи свой ответ':'Выбери свой ответ';
        var anchor=block.querySelector('a[name="variants"]');
        if(anchor&&anchor.nextSibling&&anchor.nextSibling.nodeName==='BR') anchor.parentNode.removeChild(anchor.nextSibling);
        block.insertBefore(lab,anchor?anchor.nextSibling:block.firstChild);
      }
      var inp=form.querySelector('input[type="text"][name="answer"]');
      if(inp){
        inp.setAttribute('autocomplete','off');inp.setAttribute('autocorrect','off');inp.setAttribute('autocapitalize','off');
        inp.setAttribute('spellcheck','false');inp.setAttribute('enterkeyhint','done');inp.setAttribute('placeholder','число, например 0,5');
        inp.removeAttribute('size');
        inp.addEventListener('keydown',function(ev){
          if(ev.key==='Enter'){ev.preventDefault();var b=document.querySelector('#i'+qid+' .answer-button');if(b)b.click();}
        });
      }
      form.addEventListener('submit',function(ev){ev.preventDefault();});
      if(typeof window['selectVariant'+qid]!=='function'){
        window['selectVariant'+qid]=function(k){var r=form.querySelector('input[type="radio"][name="answer"][value="'+k+'"]');if(r)r.checked=true;};
      }
      var st=saved[qid];
      if(st){
        if(inp&&st.v!=null) inp.value=st.v;
        else if(st.v){
          var r=form.querySelector('input[type="radio"][name="answer"][value="'+st.v+'"]'); if(r) r.checked=true;
          form.querySelectorAll('input[type="checkbox"][name^="test"]').forEach(function(x){if(String(st.v).indexOf(x.value)>=0)x.checked=true;});
          var sels=form.querySelectorAll('select[name^="ans"]'); String(st.v).split('').forEach(function(c,i){if(sels[i])sels[i].value=c;});
        }
        var panel=document.querySelector('#i'+qid+' .answer-panel');
        if(panel) setVisual(qid,panel,!!st.ok,st.ok?'Верно! Ответ совпал с ответом в решении.':'Неверно. Сравни с решением и попробуй ещё раз.');
      }
    });
    var s2=load();
    document.querySelectorAll('.answer-panel').forEach(function(p){ var q=panelQid(p); if(q&&s2['p2_'+q]) setSelf(p,true); });
    updateProgress();
  }

  function mobileNav(){
    var sb=document.querySelector('.sidebar'), tb=document.querySelector('.toolbar');
    if(!sb||!tb||document.querySelector('.nav-toggle')) return;
    var btn=document.createElement('button'); btn.type='button'; btn.className='nav-toggle';
    btn.setAttribute('aria-label','Открыть разделы'); btn.innerHTML='☰ Разделы';
    tb.insertBefore(btn,tb.firstChild);
    var bd=document.createElement('div'); bd.className='nav-backdrop'; document.body.appendChild(bd);
    var cl=document.createElement('div'); cl.className='nav-close';
    cl.innerHTML='<button type="button" aria-label="Закрыть меню">✕</button>'; sb.insertBefore(cl,sb.firstChild);
    function open(){document.body.classList.add('nav-open');}
    function close(){document.body.classList.remove('nav-open');}
    btn.addEventListener('click',open); bd.addEventListener('click',close); cl.querySelector('button').addEventListener('click',close);
    sb.addEventListener('click',function(ev){var a=ev.target.closest('a[href^="#"]'); if(a&&window.matchMedia('(max-width:900px)').matches) close();});
    document.addEventListener('keydown',function(ev){if(ev.key==='Escape')close();});
  }


  /* subject marks: Г — geometry (tasks 15–19, 23–25 by the FIPI criterion), А — algebra (the rest) */
  function subjOf(n){return ((n>=15&&n<=19)||(n>=23&&n<=25))?'g':'a';}
  function mark(n){
    var s=subjOf(n), el=document.createElement('span');
    el.className='subj subj-'+s; el.textContent=s==='g'?'Г':'А';
    el.title=s==='g'?'Геометрия':'Алгебра'; el.setAttribute('aria-label',el.title); return el;
  }
  function subjectMarks(){
    document.querySelectorAll('article.task').forEach(function(a){
      var d=parseInt(a.getAttribute('data-exam-number')||'',10);
      if(!d){var bb=a.querySelector('.exam-number-badge');var mm=bb&&bb.textContent.match(/№\s*(\d+)/);d=mm?+mm[1]:0;}
      if(d) a.classList.add(subjOf(d)==='g'?'task-g':'task-a');
    });
    document.querySelectorAll('.exam-number-badge').forEach(function(b){
      if(b.nextElementSibling&&b.nextElementSibling.classList.contains('subj')) return;
      var m=b.textContent.match(/№\s*(\d+)/); if(!m) return;
      b.parentNode.insertBefore(mark(+m[1]),b.nextSibling);
    });
    document.querySelectorAll('.sidebar summary, .sidebar a:not(.side-sub), h2').forEach(function(el){
      if(el.querySelector('.subj')) return;
      var t=el.textContent.trim(), m=t.match(/^(?:Задание\s*)?№\s*(\d+)(?:\s*[–-]\s*(\d+))?/); if(!m) return;
      var a=+m[1], b=m[2]?+m[2]:a;
      if(subjOf(a)!==subjOf(b)) return;
      el.insertBefore(mark(a),el.firstChild);
    });
    document.querySelectorAll('h2.chapter').forEach(function(el){ if(!el.querySelector('.subj')) el.insertBefore(mark(1),el.firstChild); });
    var leg=document.querySelector('.toolbar');
    if(leg&&!document.querySelector('.subj-legend')){
      var d=document.createElement('div'); d.className='subj-legend';
      d.innerHTML='<span class="subj subj-a">А</span> алгебра &nbsp; <span class="subj subj-g">Г</span> геометрия <span class="subj-note">(по критериям ФИПИ геометрия — задания 15–19 и 23–25; для оценки нужно не меньше 2 баллов за них)</span>';
      leg.parentNode.insertBefore(d,leg.nextSibling);
    }
  }

  window.enhanceOGECards=function(){enhanceForms();subjectMarks();};
  function init(){window.enhanceOGECards();}
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init); else init();
})();
